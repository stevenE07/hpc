//
// Created by daniel on 22/06/24.
//

#ifndef CONSTANTES_H
#define CONSTANTES_H

#define LARGO_VEHICULO 4 // todos los vehiculos miden 4m
#define NUMERO_MAXIMO_INTENTO_CAMBIO_RUTAS 7
#define NUMERO_EPOCAS_ANTE_DE_REACALCULO_DE_RUTAS 400


#endif //CONSTANTES_H
